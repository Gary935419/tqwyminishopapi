(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-buy-prompt/app-buy-prompt"],{"21f2":function(t,n,a){},"2cca":function(t,n,a){"use strict";var u=function(){var t=this,n=t.$createElement;t._self._c},e=[];a.d(n,"a",function(){return u}),a.d(n,"b",function(){return e})},"49f6":function(t,n,a){"use strict";a.r(n);var u=a("2cca"),e=a("905a");for(var c in e)"default"!==c&&function(t){a.d(n,t,function(){return e[t]})}(c);a("e9bd");var r=a("2877"),o=Object(r["a"])(e["default"],u["a"],u["b"],!1,null,"69a74b54",null);n["default"]=o.exports},"905a":function(t,n,a){"use strict";a.r(n);var u=a("92fc"),e=a.n(u);for(var c in u)"default"!==c&&function(t){a.d(n,t,function(){return u[t]})}(c);n["default"]=e.a},"92fc":function(t,n,a){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"app-buy-prompt",data:function(){return{buy_data:null}},created:function(){var t=this;t.$request({url:t.$api.index.buy_data}).then(function(n){0===n.code&&(t.buy_data=n.data)})},methods:{catchTouchMove:function(){return!1}}};n.default=u},e9bd:function(t,n,a){"use strict";var u=a("21f2"),e=a.n(u);e.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-buy-prompt/app-buy-prompt-create-component',
    {
        'components/page-component/app-buy-prompt/app-buy-prompt-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("49f6"))
        })
    },
    [['components/page-component/app-buy-prompt/app-buy-prompt-create-component']]
]);                
