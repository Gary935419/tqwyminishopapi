(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/goods/bd-detail"],{"3e70":function(t,n,e){"use strict";e.r(n);var o=e("90749"),r=e("41ce");for(var a in r)"default"!==a&&function(t){e.d(n,t,function(){return r[t]})}(a);e("6f38");var c=e("2877"),i=Object(c["a"])(r["default"],o["a"],o["b"],!1,null,"d2855008",null);n["default"]=i.exports},"41ce":function(t,n,e){"use strict";e.r(n);var o=e("9c68"),r=e.n(o);for(var a in o)"default"!==a&&function(t){e.d(n,t,function(){return o[t]})}(a);n["default"]=r.a},"6f38":function(t,n,e){"use strict";var o=e("8407"),r=e.n(o);r.a},8407:function(t,n,e){},90749:function(t,n,e){"use strict";var o=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"a",function(){return o}),e.d(n,"b",function(){return r})},"9c68":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o=function(){return Promise.all([e.e("common/vendor"),e.e("components/basic-component/app-rich/parse")]).then(e.bind(null,"cb0e"))},r={name:"bd-detail",components:{"app-rich-text":o},props:{detail:{type:String,default:function(){return""}}},created:function(){this.$store.dispatch("gConfig/setImageWidth",48)},computed:{newDetail:function(){var t="正在加载数据，模拟网络延迟2秒😝";return this.detail&&(t=this.detail),t}}};n.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/goods/bd-detail-create-component',
    {
        'components/page-component/goods/bd-detail-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("3e70"))
        })
    },
    [['components/page-component/goods/bd-detail-create-component']]
]);                
