(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-copyright/app-copyright"],{"33f0":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"app-copyright",props:{backgroundColor:{type:String,default:function(){return"#ff4544"}},link:{type:Object,default:function(){return null}},picUrl:String,text:String}};n.default=r},"38c5":function(t,n,e){},"4a8e":function(t,n,e){"use strict";var r=e("38c5"),u=e.n(r);u.a},"7d10":function(t,n,e){"use strict";e.r(n);var r=e("33f0"),u=e.n(r);for(var a in r)"default"!==a&&function(t){e.d(n,t,function(){return r[t]})}(a);n["default"]=u.a},"7fe8":function(t,n,e){"use strict";e.r(n);var r=e("8f12"),u=e("7d10");for(var a in u)"default"!==a&&function(t){e.d(n,t,function(){return u[t]})}(a);e("4a8e");var c=e("2877"),o=Object(c["a"])(u["default"],r["a"],r["b"],!1,null,"5ab1a16e",null);n["default"]=o.exports},"8f12":function(t,n,e){"use strict";var r=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"a",function(){return r}),e.d(n,"b",function(){return u})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-copyright/app-copyright-create-component',
    {
        'components/page-component/app-copyright/app-copyright-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("7fe8"))
        })
    },
    [['components/page-component/app-copyright/app-copyright-create-component']]
]);                
