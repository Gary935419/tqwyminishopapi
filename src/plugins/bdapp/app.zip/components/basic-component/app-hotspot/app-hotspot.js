(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/basic-component/app-hotspot/app-hotspot"],{"05ff":function(t,n,o){"use strict";o.r(n);var e=o("e58b"),a=o.n(e);for(var c in e)"default"!==c&&function(t){o.d(n,t,function(){return e[t]})}(c);n["default"]=a.a},7783:function(t,n,o){"use strict";var e=function(){var t=this,n=t.$createElement;t._self._c},a=[];o.d(n,"a",function(){return e}),o.d(n,"b",function(){return a})},"8d16":function(t,n,o){},"9c0a":function(t,n,o){"use strict";o.r(n);var e=o("7783"),a=o("05ff");for(var c in a)"default"!==c&&function(t){o.d(n,t,function(){return a[t]})}(c);o("a3c5");var u=o("2877"),r=Object(u["a"])(a["default"],e["a"],e["b"],!1,null,"c32e6636",null);n["default"]=r.exports},a3c5:function(t,n,o){"use strict";var e=o("8d16"),a=o.n(e);a.a},e58b:function(t,n,o){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"app-hotspot",props:{hotspot:{type:Object,default:function(){return{}}}},data:function(){return{}},onLoad:function(){},computed:{aa:function(){return this.hotspot?"left:".concat(this.hotspot.left,"rpx;top:").concat(this.hotspot.top,"rpx;width:").concat(this.hotspot.width,"rpx;height:").concat(this.hotspot.height,"rpx;"):""}}};n.default=e}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/basic-component/app-hotspot/app-hotspot-create-component',
    {
        'components/basic-component/app-hotspot/app-hotspot-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("9c0a"))
        })
    },
    [['components/basic-component/app-hotspot/app-hotspot-create-component']]
]);                
