(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/basic-component/app-form-id/app-form-id"],{"2f32":function(t,n,e){"use strict";e.r(n);var a=e("3143"),r=e.n(a);for(var i in a)"default"!==i&&function(t){e.d(n,t,function(){return a[t]})}(i);n["default"]=r.a},3143:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a=e("8de3"),r={name:"app-form-id",props:{color:String,item:Object},methods:{formSubmit:function(t){(0,a.push)(t.detail.formId),this.$emit("click",t,this.item)}}};n.default=r},"8ee9":function(t,n,e){"use strict";e.r(n);var a=e("aa8a"),r=e("2f32");for(var i in r)"default"!==i&&function(t){e.d(n,t,function(){return r[t]})}(i);e("fa3c");var o=e("2877"),u=Object(o["a"])(r["default"],a["a"],a["b"],!1,null,"754209ca",null);n["default"]=u.exports},aa8a:function(t,n,e){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"a",function(){return a}),e.d(n,"b",function(){return r})},e2da:function(t,n,e){},fa3c:function(t,n,e){"use strict";var a=e("e2da"),r=e.n(a);r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/basic-component/app-form-id/app-form-id-create-component',
    {
        'components/basic-component/app-form-id/app-form-id-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("8ee9"))
        })
    },
    [['components/basic-component/app-form-id/app-form-id-create-component']]
]);                
