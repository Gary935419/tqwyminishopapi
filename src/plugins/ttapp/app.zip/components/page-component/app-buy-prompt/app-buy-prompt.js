(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-buy-prompt/app-buy-prompt"],{"21f2":function(t,n,u){},"49f6":function(t,n,u){"use strict";u.r(n);var a=u("994f"),e=u("905a");for(var r in e)"default"!==r&&function(t){u.d(n,t,function(){return e[t]})}(r);u("e9bd");var o=u("2877"),c=Object(o["a"])(e["default"],a["a"],a["b"],!1,null,"69a74b54",null);n["default"]=c.exports},"905a":function(t,n,u){"use strict";u.r(n);var a=u("92fc"),e=u.n(a);for(var r in a)"default"!==r&&function(t){u.d(n,t,function(){return a[t]})}(r);n["default"]=e.a},"92fc":function(t,n,u){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"app-buy-prompt",data:function(){return{buy_data:null}},created:function(){var t=this;t.$request({url:t.$api.index.buy_data}).then(function(n){0===n.code&&(t.buy_data=n.data)})},methods:{catchTouchMove:function(){return!1}}};n.default=a},"994f":function(t,n,u){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},e=[];u.d(n,"a",function(){return a}),u.d(n,"b",function(){return e})},e9bd:function(t,n,u){"use strict";var a=u("21f2"),e=u.n(a);e.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-buy-prompt/app-buy-prompt-create-component',
    {
        'components/page-component/app-buy-prompt/app-buy-prompt-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("49f6"))
        })
    },
    [['components/page-component/app-buy-prompt/app-buy-prompt-create-component']]
]);                
