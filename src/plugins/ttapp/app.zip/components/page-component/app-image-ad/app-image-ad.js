(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-image-ad/app-image-ad"],{"0065":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"app-image-ad",props:{h:{type:Number,default:function(){return 1}},height:{default:function(){return"auto"}},hotspot:{type:Array,default:function(){return[]}},list:{type:Array,default:function(){return[]}},space:{type:Number,default:function(){return 0}},imageStyle:{type:Number,default:function(){return 2}},w:{type:Number,default:function(){return 25}}}};e.default=u},"605d":function(t,e,n){"use strict";n.r(e);var u=n("87aa"),a=n("d2f0");for(var r in a)"default"!==r&&function(t){n.d(e,t,function(){return a[t]})}(r);n("8ed7");var c=n("2877"),f=Object(c["a"])(a["default"],u["a"],u["b"],!1,null,"17342d67",null);e["default"]=f.exports},"87aa":function(t,e,n){"use strict";var u=function(){var t=this,e=t.$createElement;t._self._c},a=[];n.d(e,"a",function(){return u}),n.d(e,"b",function(){return a})},"8ed7":function(t,e,n){"use strict";var u=n("ccc06"),a=n.n(u);a.a},ccc06:function(t,e,n){},d2f0:function(t,e,n){"use strict";n.r(e);var u=n("0065"),a=n.n(u);for(var r in u)"default"!==r&&function(t){n.d(e,t,function(){return u[t]})}(r);e["default"]=a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-image-ad/app-image-ad-create-component',
    {
        'components/page-component/app-image-ad/app-image-ad-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("605d"))
        })
    },
    [['components/page-component/app-image-ad/app-image-ad-create-component']]
]);                
