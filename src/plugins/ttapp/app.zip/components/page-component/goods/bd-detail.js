(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/goods/bd-detail"],{"3e70":function(t,n,e){"use strict";e.r(n);var c=e("dcd8"),o=e("41ce");for(var r in o)"default"!==r&&function(t){e.d(n,t,function(){return o[t]})}(r);e("6f38");var a=e("2877"),i=Object(a["a"])(o["default"],c["a"],c["b"],!1,null,"d2855008",null);n["default"]=i.exports},"41ce":function(t,n,e){"use strict";e.r(n);var c=e("9c68"),o=e.n(c);for(var r in c)"default"!==r&&function(t){e.d(n,t,function(){return c[t]})}(r);n["default"]=o.a},"6f38":function(t,n,e){"use strict";var c=e("8407"),o=e.n(c);o.a},8407:function(t,n,e){},"9c68":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var c=function(){return Promise.all([e.e("common/vendor"),e.e("components/basic-component/app-rich/parse")]).then(e.bind(null,"cb0e"))},o={name:"bd-detail",components:{"app-rich-text":c},props:{detail:{type:String,default:function(){return""}}},created:function(){this.$store.dispatch("gConfig/setImageWidth",48)},computed:{newDetail:function(){var t="正在加载数据，模拟网络延迟2秒😝";return this.detail&&(t=this.detail),t}}};n.default=o},dcd8:function(t,n,e){"use strict";var c=function(){var t=this,n=t.$createElement;t._self._c},o=[];e.d(n,"a",function(){return c}),e.d(n,"b",function(){return o})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/goods/bd-detail-create-component',
    {
        'components/page-component/goods/bd-detail-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("3e70"))
        })
    },
    [['components/page-component/goods/bd-detail-create-component']]
]);                
