;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["pages/cats/style-one"],{"0c64":function(n,t,e){"use strict";var a=e("a55a"),u=e.n(a);u.a},"2c6f":function(n,t,e){"use strict";var a=function(){var n=this,t=n.$createElement;n._self._c},u=[];e.d(t,"a",function(){return a}),e.d(t,"b",function(){return u})},"5ec4":function(n,t,e){"use strict";e.r(t);var a=e("2c6f"),u=e("686f");for(var o in u)"default"!==o&&function(n){e.d(t,n,function(){return u[n]})}(o);e("0c64");var c=e("2877"),r=Object(c["a"])(u["default"],a["a"],a["b"],!1,null,"f14f1b48",null);t["default"]=r.exports},"686f":function(n,t,e){"use strict";e.r(t);var a=e("79ab"),u=e.n(a);for(var o in a)"default"!==o&&function(n){e.d(t,n,function(){return a[n]})}(o);t["default"]=u.a},"79ab":function(n,t,e){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a=function(){return e.e("components/page-component/app-no-goods/app-no-goods").then(e.bind(null,"8112"))},u={name:"style-one",props:["list"],components:{n:a},methods:{r:function(t){n.navigateTo({url:t.page_url})}}};t.default=u}).call(this,e("c11b")["default"])},a55a:function(n,t,e){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'pages/cats/style-one-create-component',
    {
        'pages/cats/style-one-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("5ec4"))
        })
    },
    [['pages/cats/style-one-create-component']]
]);                
