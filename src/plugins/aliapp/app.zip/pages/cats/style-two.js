;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["pages/cats/style-two"],{"0b06":function(t,n,e){"use strict";var o=function(){var t=this,n=t.$createElement;t._self._c},c=[];e.d(n,"a",function(){return o}),e.d(n,"b",function(){return c})},1380:function(t,n,e){"use strict";e.r(n);var o=e("0b06"),c=e("6dc1");for(var a in c)"default"!==a&&function(t){e.d(n,t,function(){return c[t]})}(a);e("c12a");var u=e("2877"),i=Object(u["a"])(c["default"],o["a"],o["b"],!1,null,"6203ffe4",null);n["default"]=i.exports},"6dc1":function(t,n,e){"use strict";e.r(n);var o=e("70cb"),c=e.n(o);for(var a in o)"default"!==a&&function(t){e.d(n,t,function(){return o[t]})}(a);n["default"]=c.a},"70cb":function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o=function(){return e.e("components/page-component/app-category-list/app-category-list").then(e.bind(null,"5d3f"))},c=function(){return e.e("components/page-component/app-no-goods/app-no-goods").then(e.bind(null,"8112"))},a={name:"style-two",props:["list","activeIndex","setHeight","theme"],components:{"app-category-list":o,"app-no-goods":c},methods:{active:function(t){this.$emit("active",t)},route_go:function(n){t.navigateTo({url:n})},advert:function(t){this.$emit("route_advert",t)}}};n.default=a}).call(this,e("c11b")["default"])},c12a:function(t,n,e){"use strict";var o=e("c5d0"),c=e.n(o);c.a},c5d0:function(t,n,e){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'pages/cats/style-two-create-component',
    {
        'pages/cats/style-two-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("1380"))
        })
    },
    [['pages/cats/style-two-create-component']]
]);                
