;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/basic-component/app-form-id/app-form-id"],{"2f32":function(t,n,e){"use strict";e.r(n);var r=e("3143"),i=e.n(r);for(var u in r)"default"!==u&&function(t){e.d(n,t,function(){return r[t]})}(u);n["default"]=i.a},3143:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r=e("8de3"),i={name:"app-form-id",props:{color:String,item:Object},methods:{formSubmit:function(t){(0,r.push)(t.detail.formId),this.$emit("click",t,this.item)}}};n.default=i},"8ee9":function(t,n,e){"use strict";e.r(n);var r=e("d604"),i=e("2f32");for(var u in i)"default"!==u&&function(t){e.d(n,t,function(){return i[t]})}(u);e("fa3c");var a=e("2877"),c=Object(a["a"])(i["default"],r["a"],r["b"],!1,null,"754209ca",null);n["default"]=c.exports},d604:function(t,n,e){"use strict";var r=function(){var t=this,n=t.$createElement;t._self._c},i=[];e.d(n,"a",function(){return r}),e.d(n,"b",function(){return i})},e2da:function(t,n,e){},fa3c:function(t,n,e){"use strict";var r=e("e2da"),i=e.n(r);i.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/basic-component/app-form-id/app-form-id-create-component',
    {
        'components/basic-component/app-form-id/app-form-id-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("8ee9"))
        })
    },
    [['components/basic-component/app-form-id/app-form-id-create-component']]
]);                
