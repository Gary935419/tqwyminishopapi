;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-order-goods-info/app-order-goods-info"],{1602:function(t,n,e){"use strict";e.r(n);var u=e("4c67"),a=e("9c56");for(var o in a)"default"!==o&&function(t){e.d(n,t,function(){return a[t]})}(o);e("d3f6");var r=e("2877"),f=Object(r["a"])(a["default"],u["a"],u["b"],!1,null,"5195cb61",null);n["default"]=f.exports},3276:function(t,n,e){},"4c67":function(t,n,e){"use strict";var u=function(){var t=this,n=t.$createElement;t._self._c},a=[];e.d(n,"a",function(){return u}),e.d(n,"b",function(){return a})},"5a2d":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"app-order-goods-info",data:function(){return{}},props:{goods:{type:Object,default:{}},plugin:{type:String,default:""},isLastOne:{type:Boolean,default:!0},pluginData:{type:Object,default:{}},pluginIndex:{type:Number,default:0}}};n.default=u},"9c56":function(t,n,e){"use strict";e.r(n);var u=e("5a2d"),a=e.n(u);for(var o in u)"default"!==o&&function(t){e.d(n,t,function(){return u[t]})}(o);n["default"]=a.a},d3f6:function(t,n,e){"use strict";var u=e("3276"),a=e.n(u);a.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-order-goods-info/app-order-goods-info-create-component',
    {
        'components/page-component/app-order-goods-info/app-order-goods-info-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("1602"))
        })
    },
    [['components/page-component/app-order-goods-info/app-order-goods-info-create-component']]
]);                
