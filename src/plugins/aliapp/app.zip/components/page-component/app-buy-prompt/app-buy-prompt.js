;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-buy-prompt/app-buy-prompt"],{"21f2":function(t,n,u){},"2cca":function(t,n,u){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},e=[];u.d(n,"a",function(){return a}),u.d(n,"b",function(){return e})},"49f6":function(t,n,u){"use strict";u.r(n);var a=u("2cca"),e=u("905a");for(var c in e)"default"!==c&&function(t){u.d(n,t,function(){return e[t]})}(c);u("e9bd");var r=u("2877"),o=Object(r["a"])(e["default"],a["a"],a["b"],!1,null,"69a74b54",null);n["default"]=o.exports},"905a":function(t,n,u){"use strict";u.r(n);var a=u("92fc"),e=u.n(a);for(var c in a)"default"!==c&&function(t){u.d(n,t,function(){return a[t]})}(c);n["default"]=e.a},"92fc":function(t,n,u){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"app-buy-prompt",data:function(){return{buy_data:null}},created:function(){var t=this;t.$request({url:t.$api.index.buy_data}).then(function(n){0===n.code&&(t.buy_data=n.data)})},methods:{catchTouchMove:function(){return!1}}};n.default=a},e9bd:function(t,n,u){"use strict";var a=u("21f2"),e=u.n(a);e.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-buy-prompt/app-buy-prompt-create-component',
    {
        'components/page-component/app-buy-prompt/app-buy-prompt-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("49f6"))
        })
    },
    [['components/page-component/app-buy-prompt/app-buy-prompt-create-component']]
]);                
