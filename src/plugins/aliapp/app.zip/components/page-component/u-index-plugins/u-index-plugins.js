;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/u-index-plugins/u-index-plugins"],{"03c5":function(n,t,e){"use strict";e.r(t);var u=e("ce2c"),r=e("505b");for(var c in r)"default"!==c&&function(n){e.d(t,n,function(){return r[n]})}(c);e("4125");var i=e("2877"),a=Object(i["a"])(r["default"],u["a"],u["b"],!1,null,"67c8dd5e",null);t["default"]=a.exports},"137f":function(n,t,e){},4125:function(n,t,e){"use strict";var u=e("137f"),r=e.n(u);r.a},"505b":function(n,t,e){"use strict";e.r(t);var u=e("df27"),r=e.n(u);for(var c in u)"default"!==c&&function(n){e.d(t,n,function(){return u[n]})}(c);t["default"]=r.a},ce2c:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},r=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return r})},df27:function(n,t,e){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var e={name:"u-index-plugins",props:{list:{type:Array},url:{type:String}},methods:{router:function(){n.navigateTo({url:this.url})}}};t.default=e}).call(this,e("c11b")["default"])}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/u-index-plugins/u-index-plugins-create-component',
    {
        'components/page-component/u-index-plugins/u-index-plugins-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("03c5"))
        })
    },
    [['components/page-component/u-index-plugins/u-index-plugins-create-component']]
]);                
