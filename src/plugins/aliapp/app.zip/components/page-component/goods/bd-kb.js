;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/goods/bd-kb"],{"4c29":function(n,t,e){"use strict";e.r(t);var o=e("9181"),u=e("b1a6");for(var i in u)"default"!==i&&function(n){e.d(t,n,function(){return u[n]})}(i);e("7739");var r=e("2877"),s=Object(r["a"])(u["default"],o["a"],o["b"],!1,null,"1621186a",null);t["default"]=s.exports},7739:function(n,t,e){"use strict";var o=e("f419"),u=e.n(o);u.a},9181:function(n,t,e){"use strict";var o=function(){var n=this,t=n.$createElement;n._self._c;n._isMounted||(n.e0=function(t){n.show=!1},n.e1=function(t){n.show=!1})},u=[];e.d(t,"a",function(){return o}),e.d(t,"b",function(){return u})},b1a6:function(n,t,e){"use strict";e.r(t);var o=e("bfbe"),u=e.n(o);for(var i in o)"default"!==i&&function(n){e.d(t,n,function(){return o[n]})}(i);t["default"]=u.a},bfbe:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=function(){return e.e("components/basic-component/u-popup/u-popup").then(e.bind(null,"d55a"))},u={name:"bd-kb",props:{limit:String,shipping:String,express:String,pickup:String},components:{uPopup:o},data:function(){return{show:!1,showText:"",showTitle:""}},methods:{openPopup:function(n,t){this.showText=this[n],this.showTitle=t,this.show=!0}}};t.default=u},f419:function(n,t,e){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/goods/bd-kb-create-component',
    {
        'components/page-component/goods/bd-kb-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("4c29"))
        })
    },
    [['components/page-component/goods/bd-kb-create-component']]
]);                
