;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/goods/app-goods-video"],{"36c4":function(t,e,n){"use strict";var i=n("e207"),o=n.n(i);o.a},7789:function(t,e,n){"use strict";n.r(e);var i=n("95f6"),o=n.n(i);for(var a in i)"default"!==a&&function(t){n.d(e,t,function(){return i[t]})}(a);e["default"]=o.a},"95f6":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var i={props:{video_id:{type:Number,default:0},video_url:{type:String,default:""},play:{type:Boolean,default:!1},height:{type:String,default:""},width:{type:String,default:""}},data:function(){return{loading:!0,videoCtx:null}},methods:{videoPlay:function(){this.videoCtx=my.createVideoContext("video_".concat(this.video_id),this),this.play?this.videoCtx.play():this.videoCtx.pause()},waiting:function(){this.loading=!1},pause:function(){},setPlay:function(){this.loading=!0}},watch:{play:{handler:function(){this.videoPlay()}}},beforeDestroy:function(){this.videoCtx=null}};e.default=i},"9eb5":function(t,e,n){"use strict";n.r(e);var i=n("a598"),o=n("7789");for(var a in o)"default"!==a&&function(t){n.d(e,t,function(){return o[t]})}(a);n("36c4");var u=n("2877"),d=Object(u["a"])(o["default"],i["a"],i["b"],!1,null,"0fdbf887",null);e["default"]=d.exports},a598:function(t,e,n){"use strict";var i=function(){var t=this,e=t.$createElement;t._self._c},o=[];n.d(e,"a",function(){return i}),n.d(e,"b",function(){return o})},e207:function(t,e,n){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/goods/app-goods-video-create-component',
    {
        'components/page-component/goods/app-goods-video-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("9eb5"))
        })
    },
    [['components/page-component/goods/app-goods-video-create-component']]
]);                
